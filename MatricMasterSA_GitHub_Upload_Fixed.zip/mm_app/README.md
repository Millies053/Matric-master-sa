# Matric Master SA — Android starter project

This is a self-contained Android Studio project with an offline study interface. It focuses only on:
- English Home Language: *The Picture of Dorian Gray* (Oscar Wilde)
- Afrikaans Eerste Addisionele Taal: *Fiela se kind – Die Drama* (Dalene Matthee)

## Build an APK
1. Open this folder in Android Studio on a computer.
2. Allow Gradle sync and install Android SDK Platform 35 if prompted.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

Alternatively, upload this project to a GitHub repository and run **Actions > Build Android APK > Run workflow**. Download the generated `MatricMasterSA-debug-apk` artifact.

## Important
- This ZIP is Android source code, not an installable APK or public download link.
- The app runs offline after installation. Progress and personal notes are stored on that device only; there is no account or cloud sync.
- Study notes and sample practice items are original revision aids. The DBE paper references in the app are identified by year and question; this project does not contain the complete copyrighted papers or official memoranda.
- Before public release, test the APK on multiple Android devices and add a signed release build if distributing outside a private study group.
